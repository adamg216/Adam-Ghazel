<?php
header('Content-Type: application/json');

// Vérifier paramètre
if (!isset($_GET['city']) || trim($_GET['city']) === '') {
    echo json_encode(['error' => 'Paramètre "city" manquant.']);
    exit;
}

$city = urlencode($_GET['city']);
$apiKey = 'YOUR_OPENWEATHERMAP_API_KEY'; // <-- Remplace par ta clé

$url = "https://api.openweathermap.org/data/2.5/weather?q={$city}&appid={$apiKey}&units=metric&lang=fr";

$response = @file_get_contents($url);
if ($response === false) {
    echo json_encode(['error' => 'Erreur lors de la requête API.']);
    exit;
}

echo $response;
?>