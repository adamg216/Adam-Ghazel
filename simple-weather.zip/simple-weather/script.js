document.getElementById('weather-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const city = document.getElementById('city-input').value.trim();
  if (!city) return;

  const resultEl = document.getElementById('result');
  const errorEl = document.getElementById('error');
  resultEl.classList.add('hidden');
  errorEl.classList.add('hidden');

  try {
    const res = await fetch(`weather.php?city=${encodeURIComponent(city)}`);
    const data = await res.json();
    if (data.error || data.cod === '404') {
      throw new Error(data.message || data.error || 'Ville introuvable');
    }

    document.getElementById('city-name').textContent = \`\${data.name}, \${data.sys.country}\`;
    document.getElementById('description').textContent = data.weather[0].description;
    document.getElementById('temp').textContent = Math.round(data.main.temp);
    document.getElementById('feels').textContent = Math.round(data.main.feels_like);
    document.getElementById('humidity').textContent = data.main.humidity;
    document.getElementById('wind').textContent = Math.round(data.wind.speed * 3.6); // m/s to km/h

    resultEl.classList.remove('hidden');
  } catch (err) {
    errorEl.textContent = err.message;
    errorEl.classList.remove('hidden');
  }
});
