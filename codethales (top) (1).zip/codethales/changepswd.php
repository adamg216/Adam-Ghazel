<?php
    include('function.php');
    include('logs.php');
    session_start();
    if ($_SESSION['correct']!=='ok') {
        header("Location: pageaccueil.php");
        exit;
    }
?>
<!Doctype html>
<html lang="fr">
<head><meta charset="UTF-8">
    <title>CHANGER MDP</title>
    <link rel="stylesheet" href="thales.css" />
</head>
<body>
    <div class="banner">
        <h1 class="banner-title">PHOTO_ATB</h1>
    </div>
    <br><br><br>
    <button onclick="location.href='photo.php'" class="cadre2">RETOUR</button>
<br><br><br>
    <form method='POST' action=''>
    <h1>Changer votre mot de passe</h1>
    <input class="cadre" name='ancien_mdp' placeholder="MOT DE PASSE ACTUEL" required> <br><br><br><br>
    <input class="cadre" name='nv_mdp' placeholder="NOUVEAU MOT DE PASSE" required> <br>
    <input class="cadre" name='confirmation' placeholder="CONFIRMER" required> <br>
    <button class="cadre" type='submit'>Changer votre mot de passe</button>
    </form>
    <?php 
    error_reporting(E_ALL & ~E_WARNING);
    $mdp = isset($_POST['ancien_mdp']) ? htmlspecialchars($_POST['ancien_mdp']) : '';
    $nv_mdp = isset($_POST['nv_mdp']) ? htmlspecialchars($_POST['nv_mdp']) : '';
    $confirmation = isset($_POST['confirmation']) ? htmlspecialchars($_POST['confirmation']) : '';
    if (strpos($mdp, ' ') !== false || strpos($nv_mdp, ' ') !== false || strpos($confirmation, ' ') !== false) {
    echo "Les mots de passe ne doivent pas contenir d'espaces.";
 
}
    try { 
        $bd = new PDO("sqlite:dbsite.db"); } 
        catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); }
    $sql = "SELECT LOGINE, MDP FROM COMPTES WHERE ID_C=:ID_C";
    $req = $bd->prepare ($sql);
    $req->bindParam(':ID_C', $_SESSION['ID_C']);
    $req->execute();
    $lesEnreg= $req->fetch(PDO::FETCH_ASSOC);
    $req->closeCursor();
    if ($mdp!==""){
        if ($lesEnreg['MDP']==$mdp) {
                if ($nv_mdp == $confirmation){
                    $login = $lesEnreg['LOGINE'];
                    $pswd_format= npqr();
                    $n = $pswd_format['n'];
                    $p = $pswd_format['p'];
                    $q = $pswd_format['q'];
                    $r = $pswd_format['r'];
                    $rlist = "!" . '"#$%&\'*+,-./;<=>?@\\^_`|}~';
                    $result= CheckPassword($nv_mdp, $login, $n, $p, $q, $r, $rlist);
                                if ($result == true){
                                    try { 
                                    $bd = new PDO("sqlite:dbsite.db"); } 
                                    catch (PDOException $e) { 
                                    die("Erreur: Connexion impossible"); }
                                    $sql = "UPDATE COMPTES SET MDP=:nv_mdp WHERE ID_C=:ID_C";
                                    $req = $bd->prepare ($sql);
                                    $req->bindParam(':nv_mdp', $nv_mdp);
                                    $req->bindParam(':ID_C', $_SESSION['ID_C']);
                                    $req->execute();
                                    $lesEnreg = $req->fetchall();
                                    $req->closeCursor();
                                    logs_change_password();
                                } else{
                                    echo $result;
                                }
                    
                }
                else {
                    echo "Les deux mots de passe ne sont pas identiques.";
                }
            }
        else{
            echo "Mauvais mdp";
        }
    }
    ?>
    <br><br><br><br>
    <?php 
    readnpqrules();
    ?>
</body>
</html>