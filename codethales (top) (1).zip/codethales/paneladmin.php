<?php
    include "function.php";
    include "logs.php";
    session_start();
    if ($_SESSION['correct']!=='ok') {
        header("Location: pageaccueil.php");
        exit;
    }
    if ($_SESSION['TYPE']==3){
        header("Location: photo.php");
        exit;
    }
?>
<!Doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PANEL ADMIN</title>
    <link rel="stylesheet" href="thales.css" />
</head>
    <?php try { 
        $bd = new PDO("sqlite:dbsite.db"); } 
        catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); } 
        $sql = "SELECT LOGINE FROM COMPTES WHERE ID_C = 1"; 
        $req = $bd->prepare($sql); 
        $req->execute(); 
        $lesEnreg = $req->fetch(PDO::FETCH_ASSOC); 
        $req->closeCursor ();
    ?>
    <div class="banner">
        <nav class="bandeau">
        <a class="bouton" href="photo.php">ADMIN</a>
        <h1 class="banner-title">PANEL ADMINISTRATEUR</h1>
        <a class="bouton" href="changepswd.php">Connecté(e) en tant que: <br><?php echo htmlspecialchars($_SESSION['LOGINE']); ?></a>
        </nav>
    </div>




<!-- GESTION DE COMPTES -->
    <?php
if (isset($_POST['submitchangepswdadmin'])) { //J'ai du le mettre avant, parce que si je le mettais après la boucle while la BdD faisait que crash 
    $new_pswd_admin = $_POST['changepswd'];
    $loginchangepswd = $_POST['login_target'];

    if (!empty($loginchangepswd)) { // Comme ca on aura moins de boulot après mais faut qu'à chaque fois on vérifie si un formulaire n'est pas vide sinon on l'envoie pas
        $pswd_format = npqr();
        $n = $pswd_format['n'];
        $p = $pswd_format['p'];
        $q = $pswd_format['q'];
        $r = $pswd_format['r'];
        $rlist = "!\"#$%&'*+,-./;<=>?@\\^_`|}~";
        $validation = CheckPassword($new_pswd_admin, $loginchangepswd, $n, $p, $q, $r, $rlist);

        if ($validation === true) {
            try {
                $bd_update = new PDO("sqlite:dbsite.db");
                $sql = "UPDATE COMPTES SET MDP = :new_pswd_admin WHERE LOGINE = :loginchangepswd";
                $reqUpdate = $bd_update->prepare($sql);
                $reqUpdate->bindParam(':new_pswd_admin', $new_pswd_admin);
                $reqUpdate->bindParam(':loginchangepswd', $loginchangepswd);
                $reqUpdate->execute();
                $reqUpdate->closeCursor();
                echo "Mdp changé pour : $loginchangepswd";
                logs_change_password_admin();
            } catch (PDOException $e) {
                die("Erreur: Connexion impossible à la base de données (changement mdp)");
            }
        } else {
            echo $validation;
        }
    }
}
//Pour debloquer un compte
if (isset($_POST['debloquer']) && !empty($_POST['loginunblock'])) {
    $loginunblock = $_POST['loginunblock'];
    try {
        $bd_update = new PDO("sqlite:dbsite.db");
        $sql = "UPDATE COMPTES SET COMPTEUR = 0 WHERE LOGINE = :loginunblock";
        $reqDeblock = $bd_update->prepare($sql);
        $reqDeblock->bindParam(':loginunblock', $loginunblock);
        $reqDeblock->execute();
        $reqDeblock->closeCursor();
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
}

//Pour supprimer un compte
if (isset($_POST['submit_valid_pswd']) && !empty($_POST['validpswd']) && !empty($_POST['login_target_valid'])) {
    $id_admin = $_SESSION['ID_C'];
    $pswd_admin = $_POST['validpswd'];
    $login_to_sup = $_POST['login_target_valid'];
    try {
        $bd = new PDO("sqlite:dbsite.db");
        $bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }

    $sql_admin = "SELECT MDP FROM COMPTES WHERE ID_C = :id_admin";
    $req_admin = $bd->prepare($sql_admin);
    $req_admin->bindParam(':id_admin', $id_admin, PDO::PARAM_INT);
    $req_admin->execute();
    $admin_data = $req_admin->fetch(PDO::FETCH_ASSOC);
    $req_admin->closeCursor();
    if($admin_data['MDP'] == $pswd_admin){
        $sql_delete = "DELETE FROM COMPTES WHERE LOGINE = :login_to_sup";
        $req_delete = $bd->prepare($sql_delete);
        $req_delete->bindParam(':login_to_sup', $login_to_sup);
        $req_delete->execute();
        logs_sup_user();
        echo "$login_to_sup supprimé";
    } else {
        echo "Mot de passe incorrect";
    }
}
?>

<form method="POST">
        <select name="selection" onchange="this.form.submit()">
            <option value="">FILTRE COMPTES</option>
            <option value="option1">TOUS LES COMPTES</option>
            <option value="option2">PAR TYPE</option>
            <option value="option3">BLOQUÉ</option>
            <option value="option4">PAR LOGIN</option>
        </select>
        </form>
        <?php

if (isset($_POST['selection'])) {
    $_SESSION['selection'] = $_POST['selection'];
}


if (!isset($_SESSION['selection'])) {
    $_SESSION['selection'] = ''; 
}
?>

<table>
    <tr>
        <td>
            <table class="tabofadmin">
                <tr>
                    <th>Login :</th>
                    <th>Changer Mdp :</th>
                    <th>Type :</th>
                    <th>État :</th>
                    <th>Supprimer :</th>
                </tr>

<?php
    if ($_SESSION['selection']=="option1"){
            affiche_comptes();
        }
    if ($_SESSION['selection']=="option2"){
            affiche_compte_type();
        }
    if ($_SESSION['selection']=="option3"){
            affiche_comptes_bloque();
        }
    if ($_SESSION['selection']=="option4"){
            affiche_comptes_login();
    }
?>
            </table>
        </td>
    </tr>
</table>

<!-- LES LOGS -->

<form method="POST">
        <select name="selectionlog" onchange="this.form.submit()">
            <option value="">FILTRE LOGS</option>
            <option value="optionlog1">TOUTES LES LOGS</option>
            <option value="optionlog2">PAR UTILISATEUR</option>
            <option value="optionlog3">PAR DATE</option>
            <option value="optionlog4">PAR TYPE</option>
        </select>
        </form>
        <?php

if (isset($_POST['selectionlog'])) {
    $_SESSION['selectionlog'] = $_POST['selectionlog'];
}

if (!isset($_SESSION['selectionlog'])) {
    $_SESSION['selectionlog'] = '';
}
?>

<table class="taboflogs">
    <tr>
                <th>Date :</th>
                <th>Type :</th>
                <th>Contenu :</th>
                <th>Utilisateur concerné :</th>
            </tr>
            <?php
    if ($_SESSION['selectionlog']=="optionlog1"){
            affiche_log_all();
        }
    if ($_SESSION['selectionlog']=="optionlog2"){
            affiche_log_login();
        }
    if ($_SESSION['selectionlog']=="optionlog3"){
            affiche_log_date();
        }
    if ($_SESSION['selectionlog']=="optionlog4"){
            affiche_log_type();
    }
    ?>
    </table>
    </td>
</tr>
</table>

    <?php download_logs_txt();?>
    <form method="POST">
        <button class='bouton' type="submit" name="deco">Supprimer les logs</button>
    </form>

    <?php 
    if (isset($_POST['deco'])) {
        delete_logs();
    }
    ?>
</br></br></br></br></br></br>

    <!-- CRER UN UTILISATEUR -->
 <form method='POST' action=''>
        <h1>Creer un compte</h1>
        <input class="cadre" name='login'  placeholder="LOGIN" required/> <br/>
        <input class="cadre" name='mdp' placeholder="MDP" required/> <br/>
        <label class="cadre">
        <input type="radio" name="option" value="admin" required> ADMIN
        </label>
        <label class="cadre">
        <input type="radio" name="option" value="user" required> OPÉRATEUR 
        </label>
        </div>
        </br>
 	    <button class="cadre" type='submit'>Créer le compte</button>
 	</form>
    <?php 
        $login = htmlspecialchars($_POST['login']);
        $password = htmlspecialchars($_POST['mdp']);
        if (strpos($login, ' ') !== false || strpos($password, ' ') !== false) {
        echo "Le login ou le mot de passe ne doivent pas contenir d'espaces.";
}
    
        $pswd_format= npqr();
        $n = $pswd_format['n'];
        $p = $pswd_format['p'];
        $q = $pswd_format['q'];
        $r = $pswd_format['r'];
        $rlist = "!" . '"#$%&\'*+,-./;<=>?@\\^_`|}~';
        $result= CheckPassword($password, $login, $n, $p, $q, $r, $rlist);
        if ($result===true){
            if($_POST['option']=="admin"){
                creer_admin();
                logs_create_admin_account();
            }
            if($_POST['option']=="user"){
                creer_user();
                logs_create_user_account();
            }
        }
        else{    
            echo $result;
        }
    ?>

    <form method='POST' action=''>
        <h1>Modifier le format de mot de passe</h1>
        <input class="cadre" name='nget' id='n' placeholder="Nombre de chiffres : n" type="number" required/> <br/>
        <input class="cadre" name='pget' id='p' placeholder="Nombre de minuscules : p" type="number" required/> <br/>
        <input class="cadre" name='qget' id='q' placeholder="Nombre de majuscules : q" type="number" required/> <br/>
        <input class="cadre" name='rget' id='r' placeholder="Nombre de caractères spéciaux : r" type="number" required/> <br/>
        <button class="cadre" name="npqrsubmit" type="submit">Valider le nouveau format de mot de passe</button>
    </form>
    <?php 
    $nget=(int)$_POST['nget'] ?? null;
    $pget=(int)$_POST['pget'] ?? null;
    $qget=(int)$_POST['qget'] ?? null;
    $rget=(int)$_POST['rget'] ?? null;
    try { 
        $bd = new PDO("sqlite:dbsite.db"); } 
        catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); }

        $sql = "UPDATE FORMAT_MDP SET N=:nget, P=:pget, Q=:qget, R=:rget";
        $req = $bd->prepare ($sql);
        $req->bindParam(':nget', $nget);
        $req->bindParam(':pget', $pget);
        $req->bindParam(':qget', $qget);
        $req->bindParam(':rget', $rget);
        $req->execute();
        $lesEnreg = $req->fetch(PDO::FETCH_ASSOC);
        $req->closeCursor();

        readnpqrules();
    ?>

</body>
</html>