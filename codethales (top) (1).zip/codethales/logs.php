<?php

//VALEUR 1 INFORMATION 
//VALEUR 2 WARNING
//VALEUR 3 ALERTE
function delete_logs(){
    try { 
        $bd = new PDO("sqlite:dbsite.db"); } 
        catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); }
    $sql = "DROP TABLE LOGS";
    $req = $bd->prepare ($sql);
    $req->execute();
    $req->closeCursor();
    $sql = "CREATE TABLE LOGS (
    ID_L INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    DATE_L DATE,
    TYPE_L INTEGER,
    CONTENU TEXT,
    ID_C INTEGER,

    FOREIGN KEY (ID_C) REFERENCES COMPTES (ID_C)) ";
    $req = $bd->prepare ($sql);
    $req->execute();
    $req->closeCursor();
}
function download_logs_txt(){

    try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }

    $sql = "SELECT * FROM LOGS";
    $stmt = $bd->query($sql);

    $lines = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $lines[] = implode("\t", $row);
    }
    $fichier = 'logs.txt';
    file_put_contents($fichier, implode(PHP_EOL, $lines));

    echo "<a class='bouton' href='$fichier' download>Télécharger logs.txt</a>";
}


function logs_login(){
    $id_c=($_SESSION['ID_C']);
    $date = date("d/m/Y H:i:s");
    $texte= "Connexion à un compte";
    try { 
        $bd = new PDO("sqlite:dbsite.db"); } 
        catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); }
    $sql = "INSERT INTO LOGS (DATE_L, TYPE_L ,CONTENU,ID_C) VALUES (:date_l,1,:texte, :id_c)";
    $req = $bd->prepare ($sql);
    $req->bindParam(':date_l', $date);
    $req->bindParam(':texte', $texte);
    $req->bindParam(':id_c', $id_c);
    $req->execute();
    $lesEnreg= $req->fetch(PDO::FETCH_ASSOC);
    $req->closeCursor();
}

function logs_user_bloque(){
    $date = date("d/m/Y H:i:s");
    $texte= "Un compte utilisateur a été bloqué";
    try { 
        $bd = new PDO("sqlite:dbsite.db"); } 
        catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); }
    $sql = "INSERT INTO LOGS (DATE_L, TYPE_L ,CONTENU,ID_C) VALUES (:date_l,3,:texte, :id_c)";
    $req = $bd->prepare ($sql);
    $req->bindParam(':date_l', $date);
    $req->bindParam(':texte', $texte);
    $req->bindParam(':id_c', $_SESSION['ID_C']);
    $req->execute();
    $lesEnreg= $req->fetch(PDO::FETCH_ASSOC);
    $req->closeCursor();
}

function logs_admin_bloque(){
    $date = date("d/m/Y H:i:s");
    $texte= "Un compte administrateur a été bloqué";
    try { 
        $bd = new PDO("sqlite:dbsite.db"); } 
        catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); }
    $sql = "INSERT INTO LOGS (DATE_L, TYPE_L ,CONTENU,ID_C) VALUES (:date_l,3,:texte, :id_c)";
    $req = $bd->prepare ($sql);
    $req->bindParam(':date_l', $date);
    $req->bindParam(':texte', $texte);
    $req->bindParam(':id_c', $_SESSION['ID_C']);
    $req->execute();
    $lesEnreg= $req->fetch(PDO::FETCH_ASSOC);
    $req->closeCursor();
}

function logs_change_password_admin() {
    $id_c = $_SESSION['ID_C'];
    $date = date("d/m/Y H:i:s");
    try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT LOGINE FROM COMPTES WHERE ID_C = :id_c";
    $req = $bd->prepare($sql);
    $req->bindParam(':id_c', $id_c);
    $req->execute();
    $result = $req->fetch(PDO::FETCH_ASSOC);
    $req->closeCursor();
    if (!$result) {
        die("Erreur : Aucun compte trouvé avec cet ID_C.");
    }
    $login = $result['LOGINE'];
    $texte = "Un changement de mot de passe a été effectué par : ";
    $sql = "INSERT INTO LOGS (DATE_L, TYPE_L, CONTENU, ID_C)
            VALUES (:date_l, 3, :texte, :id_c)";
    $req = $bd->prepare($sql);
    $req->bindParam(':date_l', $date);
    $req->bindParam(':texte', $texte);
    $req->bindParam(':id_c', $login);
    $req->execute();
}
function logs_change_password(){
    $ID_C=$_SESSION['ID_C'];
    $date = date("d/m/Y H:i:s");
    $login= idc_to_login($ID_C);
    try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    } 
    $texte = "Un utilisateur a changé son mot de passe";
    $sql = "INSERT INTO LOGS (DATE_L, TYPE_L, CONTENU, ID_C)
            VALUES (:date_l, 1, :texte, :id_c)";
    $req = $bd->prepare($sql);
    $req->bindParam(':date_l', $date);
    $req->bindParam(':texte', $texte);
    $req->bindParam(':id_c', $login);
    $req->execute();
}

function logs_sup_user(){
    $id_c = $_SESSION['ID_C'];
    $date = date("d/m/Y H:i:s");
    try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT LOGINE FROM COMPTES WHERE ID_C = :id_c";
    $req = $bd->prepare($sql);
    $req->bindParam(':id_c', $id_c);
    $req->execute();
    $result = $req->fetch(PDO::FETCH_ASSOC);
    $req->closeCursor();
    if (!$result) {
        die("Erreur : Aucun compte trouvé avec cet ID_C.");
    }
    $login = $result['LOGINE'];
    $texte = "Un compte a été supprimé par : ";
    $sql = "INSERT INTO LOGS (DATE_L, TYPE_L, CONTENU, ID_C)
            VALUES (:date_l, 2, :texte, :id_c)";
    $req = $bd->prepare($sql);
    $req->bindParam(':date_l', $date);
    $req->bindParam(':texte', $texte);
    $req->bindParam(':id_c', $login);
    $req->execute();
}

function logs_create_admin_account(){
    $date = date("d/m/Y H:i:s");
    $texte= "Création d'un compte administrateur";
    try { 
        $bd = new PDO("sqlite:dbsite.db"); } 
        catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); }
    $sql = "INSERT INTO LOGS (DATE_L, TYPE_L ,CONTENU,ID_C) VALUES (:date_l,2,:texte, :id_c)";
    $req = $bd->prepare ($sql);
    $req->bindParam(':date_l', $date);
    $req->bindParam(':texte', $texte);
    $req->bindParam(':id_c', $_SESSION['ID_C']);
    $req->execute();
    $lesEnreg= $req->fetch(PDO::FETCH_ASSOC);
    $req->closeCursor();
}

function logs_create_user_account(){
    $date = date("d/m/Y H:i:s");
    $texte= "Création d'un compte utilisateur";
    try { 
        $bd = new PDO("sqlite:dbsite.db"); } 
        catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); }
    $sql = "INSERT INTO LOGS (DATE_L, TYPE_L ,CONTENU,ID_C) VALUES (:date_l,1,:texte, :id_c)";
    $req = $bd->prepare ($sql);
    $req->bindParam(':date_l', $date);
    $req->bindParam(':texte', $texte);
    $req->bindParam(':id_c', $_SESSION['ID_C']);
    $req->execute();
    $lesEnreg= $req->fetch(PDO::FETCH_ASSOC);
    $req->closeCursor();
}

?>