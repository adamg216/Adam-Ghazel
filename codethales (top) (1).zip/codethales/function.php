<?php
// Fonction de signalement
function report($id_p){
    try { 
        $bd = new PDO("sqlite:dbsite.db"); 
    } catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); 
    }
    $sql = "SELECT SIGNALEMENT FROM PHOTOS WHERE ID_P= :id_p";
    $req = $bd->prepare ($sql);
    $req->bindParam(':id_p', $id_p);
    $req->execute();
    $lesEnreg= $req->fetch(PDO::FETCH_ASSOC);
    $req->closeCursor();
    if ($lesEnreg['SIGNALEMENT']==0){
        $sql = "UPDATE PHOTOS SET SIGNALEMENT = SIGNALEMENT+1 WHERE ID_P= :id_p";
        $req = $bd->prepare ($sql);
        $req->bindParam(':id_p', $id_p);
        $req->execute();
        $req->closeCursor();
    }
    }

function delete_pic($id_p){
    try { 
        $bd = new PDO("sqlite:dbsite.db"); 
    } catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); 
    }
    $sql = "DELETE FROM PHOTOS WHERE ID_P= :id_p";
    $req = $bd->prepare ($sql);
    $req->bindParam(':id_p', $id_p);
    $req->execute();
    $lesEnreg= $req->fetch(PDO::FETCH_ASSOC);
    $req->closeCursor();
    if ($lesEnreg['SIGNALEMENT']==0){
        $sql = "UPDATE PHOTOS SET SIGNALEMENT = SIGNALEMENT+1 WHERE ID_P= :id_p";
        $req = $bd->prepare ($sql);
        $req->bindParam(':id_p', $id_p);
        $req->execute();
        $req->closeCursor();
    }
    }

function npqr(){
    try { 
        $bd = new PDO("sqlite:dbsite.db"); } 
        catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); } 
        $sql = "SELECT * FROM FORMAT_MDP "; 
        $req = $bd->prepare($sql); 
        $req->execute(); 
        $lesEnreg = $req->fetch(PDO::FETCH_ASSOC);
        $req->closeCursor ();
         return [
            'n' => $lesEnreg['N'],
            'p' => $lesEnreg['P'],
            'q' => $lesEnreg['Q'],
            'r' => $lesEnreg['R']
        ];
    }

function readnpqrules(){
    $pswd_format= npqr(); 
    ?>
    <p class="milieu">ATTENTION<br>LE MOT DE PASSE DOIT CONTENIR:<br>
        <?php echo htmlspecialchars($pswd_format['n']); ?> chiffre(s).<br>
        <?php echo htmlspecialchars($pswd_format['p']); ?> lettre(s) en minuscule(s).<br>
        <?php echo htmlspecialchars($pswd_format['q']); ?> lettre(s) en majuscule(s).<br>
        <?php echo htmlspecialchars($pswd_format['r']); ?> caractère(s) spécial(aux).</p>
    <?php
    }
    ?>
<?php

$rlist= "!" . '"#$%&\'*+,-./;<=>?@\\^_`|}~';
function CheckPassword($password, $login, $n, $p, $q, $r, $rlist){
    if (strpos($password, $login) !== false) {  
        return "Erreur : Le mot de passe contient le login.";
    }
    
    if (preg_match_all('/\d/', $password) < $n) {
     return  "Le mot de passe doit contenir au moins $n chiffre(s).";
    }
    if (preg_match_all('/[a-z]/', $password) < $p) {
     return "Le mot de passe doit contenir au moins $p lettre(s) minuscule(s).";
    }
    if (preg_match_all('/[A-Z]/', $password) < $q) {
     return "Le mot de passe doit contenir au moins $q lettre(s) majuscule(s).";
    }
    $SCPattern = '/[' . preg_quote($rlist, '/') . ']/';
    if (preg_match_all($SCPattern, $password) < $r) {
     return "Le mot de passe doit contenir au moins $r caractère(s) spéciau(x).";
    }

    return true;
    }

// Fonction d'affichage de toutes les photos
function affiche_toutes_photos(){
    try { 
        $bd = new PDO("sqlite:dbsite.db"); 
    } catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); 
    } 
    $sql = "SELECT CHEMIN,TITRE,ID_P,SIGNALEMENT FROM PHOTOS ORDER BY ID_P ASC"; 
    $req = $bd->prepare($sql); 
    $req->execute(); 
    $lesEnreg = $req->fetchAll(PDO::FETCH_ASSOC); 
    $req->closeCursor();

    echo "<table><tr><th>Titre</th><th>Image</th><th>Action</th><th>État</th></tr>";
    foreach ($lesEnreg as $enreg) { 
        echo "<tr>";
        echo "<td>" . htmlspecialchars($enreg['TITRE']) . "</td>";
        echo "<td><img src='" . htmlspecialchars($enreg['CHEMIN']) . "' width='200' height='150'></td>";
        echo "<td>
            <form method='POST'>
                <input type='hidden' name='signaler_photo' value='" . htmlspecialchars($enreg['ID_P']) . "'>
                <button type='submit'>Signaler</button>
            </form>";
        if ($_SESSION['TYPE']==1 || $_SESSION['TYPE']==2){
            echo"
            <form method='POST'>
                <input type='hidden' name='supprimer_photo' value='" . htmlspecialchars($enreg['ID_P']) . "'>
                <button type='submit'>Supprimer</button>
            </form>
              </td>";
        }
        
        if (isset($_POST['signaler_photo'])) {
            report($_POST['signaler_photo']);
        }
        if (isset($_POST['supprimer_photo'])) {
            delete_pic($_POST['supprimer_photo']);
        }
        echo "<td>" . ($enreg['SIGNALEMENT'] > 0 ? "Déjà signalée" : "Non signalée") . "</td>";
        echo "</tr>";
    } 
    echo "</table>";
    }

// Fonction d'affichage des photos par titre
function affiche_photos_par_titre($titre){
    try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT ID_P, TITRE, CHEMIN, SIGNALEMENT FROM PHOTOS WHERE TITRE = :titre";
    $req = $bd->prepare($sql);
    $req->execute([':titre' => $titre]);

    while ($photo = $req->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($photo['TITRE']) . "</td>";
        echo "<td><img src='" . htmlspecialchars($photo['CHEMIN']) . "' width='200' height='150'></td>";
        echo "<td>
            <form method='POST'>
                <input type='hidden' name='signaler_photo' value='" . htmlspecialchars($photo['ID_P']) . "'>
                <button type='submit'>Signaler</button>
            </form>";
        if ($_SESSION['TYPE']==1 || $_SESSION['TYPE']==2){
            echo"
            <form method='POST'>
                <input type='hidden' name='supprimer_photo' value='" . htmlspecialchars($photo['ID_P']) . "'>
                <button type='submit'>Supprimer</button>
            </form>
              </td>";
        }
        
        if (isset($_POST['signaler_photo'])) {
            report($_POST['signaler_photo']);
        }
        if (isset($_POST['supprimer_photo'])) {
            delete_pic($_POST['supprimer_photo']);
        }
        echo "<td>" . ($photo['SIGNALEMENT'] > 0 ? "Déjà signalée" : "Non signalée") . "</td>";
        echo "</tr>";
    }
    $req->closeCursor();
    }

// Fonction d'affichage des photos par utilisateur
function affiche_photos_par_user($login){
    try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $ID_C=login_to_idc($login);
    $sql = "SELECT ID_P, TITRE, CHEMIN, SIGNALEMENT FROM PHOTOS WHERE LOGINE =:ID_C";
    $req = $bd->prepare($sql);
    $req->execute([':ID_C' => $ID_C]);
    while ($photo = $req->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($photo['TITRE']) . "</td>";
            echo "<td><img src='" . htmlspecialchars($photo['CHEMIN']) . "' width='200' height='150'></td>";
            echo "<td>
            <form method='POST'>
                <input type='hidden' name='signaler_photo' value='" . htmlspecialchars($photo['ID_P']) . "'>
                <button type='submit'>Signaler</button>
            </form>";
        if ($_SESSION['TYPE']==1 || $_SESSION['TYPE']==2){
            echo"
            <form method='POST'>
                <input type='hidden' name='supprimer_photo' value='" . htmlspecialchars($photo['ID_P']) . "'>
                <button type='submit'>Supprimer</button>
            </form>
              </td>";
        }
        
        if (isset($_POST['signaler_photo'])) {
            report($_POST['signaler_photo']);
        }
        if (isset($_POST['supprimer_photo'])) {
            delete_pic($_POST['supprimer_photo']);
        }
            echo "<td>" . ($photo['SIGNALEMENT'] > 0 ? "Déjà signalée" : "Non signalée") . "</td>";
            echo "</tr>";
    }
    $req->closeCursor();
    }


function print_reported_pic(){
    try { 
        $bd = new PDO("sqlite:dbsite.db"); 
    } catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); 
    } 
    $sql = "SELECT CHEMIN,TITRE,ID_P,SIGNALEMENT FROM PHOTOS WHERE SIGNALEMENT=1"; 
    $req = $bd->prepare($sql); 
    $req->execute(); 
    $lesEnreg = $req->fetchAll(PDO::FETCH_ASSOC); 
    $req->closeCursor();

    echo "<table><tr><th>Titre</th><th>Image</th><th>Action</th><th>État</th></tr>";
    foreach ($lesEnreg as $enreg) { 
        echo "<tr>";
        echo "<td>" . htmlspecialchars($enreg['TITRE']) . "</td>";
        echo "<td><img src='" . htmlspecialchars($enreg['CHEMIN']) . "' width='200' height='150'></td>";
        echo "<td>
            <form method='POST'>
                <input type='hidden' name='signaler_photo' value='" . htmlspecialchars($enreg['ID_P']) . "'>
                <button type='submit'>Signaler</button>
            </form>";
        if ($_SESSION['TYPE']==1 || $_SESSION['TYPE']==2){
            echo"
            <form method='POST'>
                <input type='hidden' name='supprimer_photo' value='" . htmlspecialchars($enreg['ID_P']) . "'>
                <button type='submit'>Supprimer</button>
            </form>
              </td>";
        }
        
        if (isset($_POST['signaler_photo'])) {
            report($_POST['signaler_photo']);
        }
        if (isset($_POST['supprimer_photo'])) {
            delete_pic($_POST['supprimer_photo']);
        }
        echo "<td>" . ($enreg['SIGNALEMENT'] > 0 ? "Déjà signalée" : "Non signalée") . "</td>";
        echo "</tr>";
    } 
    echo "</table>";
    }

function creer_user(){
    $login = htmlspecialchars($_POST['login']);
        $mdp = htmlspecialchars($_POST['mdp']);
        try { 
        $bd = new PDO("sqlite:dbsite.db"); } 
        catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); }

        $sql = "INSERT INTO COMPTES (TYPE, LOGINE, MDP) VALUES (3, :login, :mdp)";
        $req = $bd->prepare ($sql);
        $req->bindParam(':login', $login);
        $req->bindParam(':mdp', $password);
        $req->execute();
        $lesEnreg = $req->fetchall();
        $req->closeCursor();
    }


function creer_admin(){
    $login = htmlspecialchars($_POST['login']);
        $mdp = htmlspecialchars($_POST['mdp']);
        try { 
        $bd = new PDO("sqlite:dbsite.db"); } 
        catch (PDOException $e) { 
        die("Erreur: Connexion impossible"); }

        $sql = "INSERT INTO COMPTES (TYPE, LOGINE, MDP) VALUES (2, :login, :mdp)";
        $req = $bd->prepare ($sql);
        $req->bindParam(':login', $login);
        $req->bindParam(':mdp', $password);
        $req->execute();
        $lesEnreg = $req->fetchall();
        $req->closeCursor();
    }





// FILTRE COMPTES
function affiche_comptes(){
    try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT LOGINE, TYPE, COMPTEUR FROM COMPTES ORDER BY LOGINE ASC";
    $req = $bd->prepare($sql);
    $req->execute();
    while ($range = $req->fetch(PDO::FETCH_ASSOC)) {
        if ($range['TYPE'] > 1){
            echo "<tr>";
        echo "<td>" . htmlspecialchars($range['LOGINE']) . "</td>";
        echo "<td>";
        ?>
        <form method='POST'>
            <input name="changepswd" placeholder="Nouveau mot de passe" required>
            <input type="hidden" name="login_target" value="<?php echo htmlspecialchars($range['LOGINE']); ?>"> <!-- La je donne une sorte d'id unique (le login_target) pour les forms, comme ca on reconnaitra les bons formulaires -->
            <button type="submit" name="submitchangepswdadmin">Valider</button>
        </form>
        <?php
        echo "</td>";
        echo "<td>";
        if ($range['TYPE']== 1) {
                echo "Super-admin";
            } elseif($range['TYPE']== 2) {
                echo "Admin";
            } elseif($range['TYPE']==3) {
                echo "Utilisateur";
            }
        echo "</td>";
        echo "<td>";
        if ($range['COMPTEUR'] < 3) {
            echo "Compte pas bloqué";
        } else {
            ?>
            <form method='POST'>
                <input type="hidden" name="loginunblock" value="<?php echo htmlspecialchars($range['LOGINE']); ?>">
                <button type="submit" name="debloquer">Débloquer</button>
            </form>
            <?php
        }
        echo "</td>";
        //Rajout de la ligne supprimer pour la copier coller
        echo "<td>";
        ?><form method='POST'>
            <input name="validpswd" placeholder="Valider son mot de passe" required>
            <input type="hidden" name="login_target_valid" value="<?php echo htmlspecialchars($range['LOGINE']); ?>"> 
            <button type="submit" name="submit_valid_pswd">Supprimer</button>
        </form><?php
        echo "</td>";
        echo "</tr>";
    } else {
        echo "<td> SUPER ADMIN </td> <td> SUPER ADMIN </td> <td> SUPER ADMIN </td> <td> SUPER ADMIN </td>  <td> SUPER ADMIN </td> </tr>"; 
    }
        }
        
    $req->closeCursor();
    }

function affiche_comptes_bloque(){
    //POUR CELLE LA PAS BESOIND DE METTRE LA CONDITION DU SUPER ADMIN PAS AFFICHE COMME SON COMPTE PEUT PAS ÊTRE BLOQUE
    try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT LOGINE, TYPE, COMPTEUR FROM COMPTES WHERE COMPTEUR=3";
    $req = $bd->prepare($sql);
    $req->execute();
    while ($range = $req->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($range['LOGINE']) . "</td>";
        echo "<td>";
        ?>
        <form method='POST'>
            <input name="changepswd" placeholder="Nouveau mot de passe" required>
            <input type="hidden" name="login_target" value="<?php echo htmlspecialchars($range['LOGINE']); ?>"> <!-- La je donne une sorte d'id unique (le login_target) pour les forms, comme ca on reconnaitra les bons formulaires -->
            <button type="submit" name="submitchangepswdadmin">Valider</button>
        </form>
        <?php
        echo "</td>";
        echo "<td>";
        if ($range['TYPE']== 1) {
                echo "Super-admin";
            } elseif($range['TYPE']== 2) {
                echo "Admin";
            } elseif($range['TYPE']==3) {
                echo "Utilisateur";
            }
        echo "</td>";
        echo "<td>";
        if ($range['COMPTEUR'] < 3) {
            echo "Compte pas bloqué";
        } else {
            ?>
            <form method='POST'>
                <input type="hidden" name="loginunblock" value="<?php echo htmlspecialchars($range['LOGINE']); ?>">
                <button type="submit" name="debloquer">Débloquer</button>
            </form>
            <?php
        }
        echo "</td>";
        echo "<td>";
        ?><form method='POST'>
            <input name="validpswd" placeholder="Valider son mot de passe" required>
            <input type="hidden" name="login_target_valid" value="<?php echo htmlspecialchars($range['LOGINE']); ?>"> 
            <button type="submit" name="submit_valid_pswd">Supprimer</button>
        </form><?php
        echo "</td>";
        echo "</tr>";
    }
    $req->closeCursor();
    }

function affiche_compte_type(){ 
    //Toujours pas de mettre un controle sur le compte super admin besoin comme le choix c'est soit admin soit user
    ?>
        <form method="POST" action="">
        <label class="cadre">
        <input type="radio" name="option" value="admin" required>ADMIN
        </label>
        <label class="cadre">
        <input type="radio" name="option" value="user" required>OPÉRATEUR 
        </label>
        <button class="cadre" type='submit'>Selectionner</button>
        </form><?php
        // Si c'est un compte admin qui est choisi :
        
        if  (isset($_POST['option']) && $_POST['option'] == 'admin'){
            try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT LOGINE, TYPE, COMPTEUR FROM COMPTES WHERE TYPE=2";
    $req = $bd->prepare($sql);
    $req->execute();
    while ($range = $req->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($range['LOGINE']) . "</td>";
        echo "<td>";
        ?>
        <form method='POST'>
            <input name="changepswd" placeholder="Nouveau mot de passe" required>
            <input type="hidden" name="login_target" value="<?php echo htmlspecialchars($range['LOGINE']); ?>"> <!-- La je donne une sorte d'id unique (le login_target) pour les forms, comme ca on reconnaitra les bons formulaires -->
            <button type="submit" name="submitchangepswdadmin">Valider</button>
        </form>
        <?php
        echo "</td>";
        echo "<td>";
        if ($range['TYPE']== 1) {
                echo "Super-admin";
            } elseif($range['TYPE']== 2) {
                echo "Admin";
            } elseif($range['TYPE']==3) {
                echo "Utilisateur";
            }
        echo "</td>";
        echo "<td>";
        if ($range['COMPTEUR'] < 3) {
            echo "Compte pas bloqué";
        } else {
            ?>
            <form method='POST'>
                <input type="hidden" name="loginunblock" value="<?php echo htmlspecialchars($range['LOGINE']); ?>">
                <button type="submit" name="debloquer">Débloquer</button>
            </form>
            <?php
        }
        echo "</td>";
        echo "<td>";
    ?><form method='POST'>
        <input name="validpswd" placeholder="Valider son mot de passe" required>
        <input type="hidden" name="login_target_valid" value="<?php echo htmlspecialchars($range['LOGINE']); ?>"> 
        <button type="submit" name="submit_valid_pswd">Supprimer</button>
    </form><?php
    echo "</td>";
        echo "</tr>";
    }
    $req->closeCursor();
    } elseif  (isset($_POST['option']) && $_POST['option'] == 'user'){
        try {
            $bd = new PDO("sqlite:dbsite.db");
        } catch (PDOException $e) {
            die("Erreur: Connexion impossible");
        }
        $sql = "SELECT LOGINE, TYPE, COMPTEUR FROM COMPTES WHERE TYPE=3";
        $req = $bd->prepare($sql);
        $req->execute();
        while ($range = $req->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($range['LOGINE']) . "</td>";
            echo "<td>";
            ?>
            <form method='POST'>
                <input name="changepswd" placeholder="Nouveau mot de passe" required>
                <input type="hidden" name="login_target" value="<?php echo htmlspecialchars($range['LOGINE']); ?>"> <!-- La je donne une sorte d'id unique (le login_target) pour les forms, comme ca on reconnaitra les bons formulaires -->
                <button type="submit" name="submitchangepswdadmin">Valider</button>
            </form>
            <?php
            echo "</td>";
            echo "<td>";
            if ($range['TYPE']== 1) {
                    echo "Super-admin";
                } elseif($range['TYPE']== 2) {
                    echo "Admin";
                } elseif($range['TYPE']==3) {
                    echo "Utilisateur";
                }
            echo "</td>";
            echo "<td>";
            if ($range['COMPTEUR'] < 3) {
                echo "Compte pas bloqué";
            } else {
                ?>
                <form method='POST'>
                    <input type="hidden" name="loginunblock" value="<?php echo htmlspecialchars($range['LOGINE']); ?>">
                    <button type="submit" name="debloquer">Débloquer</button>
                </form>
                <?php
            }
            echo "</td>";
            echo "<td>";
        ?><form method='POST'>
            <input name="validpswd" placeholder="Valider son mot de passe" required>
            <input type="hidden" name="login_target_valid" value="<?php echo htmlspecialchars($range['LOGINE']); ?>"> 
            <button type="submit" name="submit_valid_pswd">Supprimer</button>
        </form><?php
        echo "</td>";
            echo "</tr>";
        }
        $req->closeCursor();
    }

    }

function affiche_comptes_login(){
    ?>
    <form method="POST" action="">
        <input type="text" name="searchlogin" placeholder="Entrer un login" required>
        <button type="submit" name="validatesearchlogin">Rechercher</button>
    </form>
    <?php
    if (isset($_POST['validatesearchlogin'])){
        try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT LOGINE, TYPE, COMPTEUR FROM COMPTES WHERE LOGINE=:searchlogin";
    $req = $bd->prepare($sql);
    $req->execute(['searchlogin' => $_POST['searchlogin']]);
    while ($range = $req->fetch(PDO::FETCH_ASSOC)) {
        if ($range['TYPE'] > 1) {
            echo "<tr>";
        echo "<td>" . htmlspecialchars($range['LOGINE']) . "</td>";
        echo "<td>";
        ?>
        <form method='POST'>
            <input name="changepswd" placeholder="Nouveau mot de passe" required>
            <input type="hidden" name="login_target" value="<?php echo htmlspecialchars($range['LOGINE']); ?>"> <!-- La je donne une sorte d'id unique (le login_target) pour les forms, comme ca on reconnaitra les bons formulaires -->
            <button type="submit" name="submitchangepswdadmin">Valider</button>
        </form>
        <?php
        echo "</td>";
        echo "<td>";
        if ($range['TYPE']== 1) {
                echo "Super-admin";
            } elseif($range['TYPE']== 2) {
                echo "Admin";
            } elseif($range['TYPE']==3) {
                echo "Utilisateur";
            }
        echo "</td>";
        echo "<td>";
        if ($range['COMPTEUR'] < 3) {
            echo "Compte pas bloqué";
        } else {
            ?>
            <form method='POST'>
                <input type="hidden" name="loginunblock" value="<?php echo htmlspecialchars($range['LOGINE']); ?>">
                <button type="submit" name="debloquer">Débloquer</button>
            </form>
            <?php
        }
        echo "</td>";
        echo "<td>";
    ?><form method='POST'>
        <input name="validpswd" placeholder="Valider son mot de passe" required>
        <input type="hidden" name="login_target_valid" value="<?php echo htmlspecialchars($range['LOGINE']); ?>"> 
        <button type="submit" name="submit_valid_pswd">Supprimer</button>
    </form><?php
    echo "</td>";
        echo "</tr>";
        }else {
            echo "<td> SUPER ADMIN </td> <td> SUPER ADMIN </td> <td> SUPER ADMIN </td> <td> SUPER ADMIN </td>  <td> SUPER ADMIN </td> </tr>";
        }
    }
    $req->closeCursor();
    }
    }









// FILTRE DES LOG
function affiche_log_all(){
    try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT DATE_L, TYPE_L, CONTENU, ID_C FROM LOGS";
    $req = $bd->prepare($sql);
    $req->execute();
    while ($range = $req->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($range['DATE_L']) ."</td>";
        echo "</td>";
        echo "<td>";  //Cette ligne est un peu bizare mais enfaite en php on peut pas mettre de if dans un concatenation (genre echo . if bah ca marche pas)//
        if ($range['TYPE_L']== 1) {
            echo "INFORMATION";
        } elseif($range['TYPE_L']== 2) {
            echo "WARNING";
        } else {
            echo "ALERTE";
        }
        echo "</td>";
        echo "<td>"; 
        echo $range['CONTENU'];
        echo "</td>";
        echo "<td>";
        echo $range['ID_C'];
        echo "</td>";
        echo "</tr>";
    }
    $req->closeCursor();
}

function affiche_log_type(){
    ?><form method="POST" action="">
        <label class="cadre">
        <input type="radio" name="option" value="warning" required>ALERT
        </label>
        <label class="cadre">
        <input type="radio" name="option" value="alert" required>WARNING 
        </label>
        <label class="cadre">
        <input type="radio" name="option" value="info" required>INFORMATION 
        </label>
        <button class="cadre" type='submit'>Selectionner</button>
        </form>
        <?php
        if  (isset($_POST['option']) && $_POST['option'] == 'warning'){
            try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT DATE_L, TYPE_L, CONTENU, ID_C FROM LOGS WHERE TYPE_L=3";
    $req = $bd->prepare($sql);
    $req->execute();
    while ($range = $req->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($range['DATE_L']) ."</td>";
        echo "</td>";
        echo "<td>";  //Cette ligne est un peu bizare mais enfaite en php on peut pas mettre de if dans un concatenation (genre echo . if bah ca marche pas)//
        if ($range['TYPE_L']== 1) {
            echo "INFORMATION";
        } elseif($range['TYPE_L']== 2) {
            echo "WARNING";
        } elseif($range['TYPE_L']==3) {
            echo "ALERTE";
        }
        echo "</td>";
        echo "<td>"; 
        echo $range['CONTENU'];
        echo "</td>";
        echo "<td>";
        echo $_SESSION['ID_C'];
        echo "</td>";
        echo "</tr>";
    }
    $req->closeCursor();
} elseif  (isset($_POST['option']) && $_POST['option'] == 'alert'){
            try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT DATE_L, TYPE_L, CONTENU, ID_C FROM LOGS WHERE TYPE_L=2";
    $req = $bd->prepare($sql);
    $req->execute();
    while ($range = $req->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($range['DATE_L']) ."</td>";
        echo "</td>";
        echo "<td>";  //Cette ligne est un peu bizare mais enfaite en php on peut pas mettre de if dans un concatenation (genre echo . if bah ca marche pas)//
        if ($range['TYPE_L']== 1) {
            echo "INFORMATION";
        } elseif($range['TYPE_L']== 2) {
            echo "WARNING";
        } else {
            echo "ALERTE";
        }
        echo "</td>";
        echo "<td>"; 
        echo $range['CONTENU'];
        echo "</td>";
        echo "<td>";
        echo $range['ID_C'];
        echo "</td>";
        echo "</tr>";
    }
    $req->closeCursor();
} elseif  (isset($_POST['option']) && $_POST['option'] == 'info'){
            try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT DATE_L, TYPE_L, CONTENU, ID_C FROM LOGS WHERE TYPE_L=1";
    $req = $bd->prepare($sql);
    $req->execute();
    while ($range = $req->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($range['DATE_L']) ."</td>";
        echo "</td>";
        echo "<td>";  //Cette ligne est un peu bizare mais enfaite en php on peut pas mettre de if dans un concatenation (genre echo . if bah ca marche pas)//
        if ($range['TYPE_L']== 1) {
            echo "INFORMATION";
        } elseif($range['TYPE_L']== 2) {
            echo "WARNING";
        } else {
            echo "ALERTE";
        }
        echo "</td>";
        echo "<td>"; 
        echo $range['CONTENU'];
        echo "</td>";
        echo "<td>";
        echo $range['ID_C'];
        echo "</td>";
        echo "</tr>";
    }
    $req->closeCursor();

}
}

function affiche_log_date() {
    ?>
    <form method="POST" action="">
        <input type="date" name="searchdate" placeholder="Entrer une date" required>
        <button type="submit" name="validate">Rechercher</button>
    </form>
    <?php
    if (isset($_POST['validate'])) {
        try {
            $bd = new PDO("sqlite:dbsite.db");
        } catch (PDOException $e) {
            die("Erreur: Connexion impossible");
        }
        $dateInput = $_POST['searchdate'];  // Conversion de la date pour correspondre à celle dans la base
        $timestamp = strtotime($dateInput);
        $searchDate = date("d/m/Y", $timestamp); 
        $sql = "SELECT DATE_L, TYPE_L, CONTENU, ID_C FROM LOGS WHERE DATE_L LIKE :searchdate";
        $req = $bd->prepare($sql);
        $req->execute(['searchdate' => $searchDate . '%']); //  % premet d'ignorer l'heure
        while ($range = $req->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($range['DATE_L']) . "</td>";
            echo "<td>";
            if ($range['TYPE_L'] == 1) {
                echo "INFORMATION";
            } elseif ($range['TYPE_L'] == 2) {
                echo "WARNING";
            } else {
                echo "ALERTE";
            }
            echo "</td>";
            echo "<td>" . htmlspecialchars($range['CONTENU']) . "</td>";
            echo "<td>" . htmlspecialchars($range['ID_C']) . "</td>";
            echo "</tr>";
        }
        $req->closeCursor();
    }
}

function affiche_log_login(){
     ?> <form method="POST" action="">
        <input type="text" name="searchloginlog" placeholder="Entrer un login" required>
        <button type="submit" name="validatesearchloginlog">Rechercher</button>
    </form>
    <?php
    if (isset($_POST['validatesearchloginlog'])){
         try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $searchlogin = $_POST['searchloginlog'];
    $sql = "SELECT LOGS.DATE_L, LOGS.TYPE_L, LOGS.CONTENU, LOGS.ID_C, COMPTES.LOGINE 
                FROM LOGS 
                JOIN COMPTES ON LOGS.ID_C = COMPTES.ID_C 
                WHERE COMPTES.LOGINE = :searchlogin";
    $req = $bd->prepare($sql);
    $req->execute(['searchlogin' => $searchlogin]);
    while ($range = $req->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($range['DATE_L']) ."</td>";
        echo "</td>";
        echo "<td>";  //Cette ligne est un peu bizare mais enfaite en php on peut pas mettre de if dans un concatenation (genre echo . if bah ca marche pas)//
        if ($range['TYPE_L']== 1) {
            echo "INFORMATION";
        } elseif($range['TYPE_L']== 2) {
            echo "WARNING";
        } else {
            echo "ALERTE";
        }
        echo "</td>";
        echo "<td>"; 
        echo $range['CONTENU'];
        echo "</td>";
        echo "<td>";
        echo $range['ID_C'];
        echo "</td>";
        echo "</tr>";
    }
    $req->closeCursor();
}
}

function idc_to_login($ID_C){
      try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT LOGINE FROM COMPTES WHERE ID_C = :ID_C";
    $req = $bd->prepare($sql);
    $req->bindParam(':ID_C', $ID_C, PDO::PARAM_INT);
    $req->execute();
    $resultat = $req->fetch(PDO::FETCH_ASSOC);
    $req->closeCursor();
    return $resultat['LOGINE'];
}

function login_to_idc($login){
     try {
        $bd = new PDO("sqlite:dbsite.db");
    } catch (PDOException $e) {
        die("Erreur: Connexion impossible");
    }
    $sql = "SELECT ID_C FROM COMPTES WHERE LOGINE = :login";
    $req = $bd->prepare($sql);
     $req->bindParam(':login', $login, PDO::PARAM_STR); 
    $req->execute();
    $resultat = $req->fetch(PDO::FETCH_ASSOC);
    $req->closeCursor();
    return $resultat['ID_C'];
}
?>


