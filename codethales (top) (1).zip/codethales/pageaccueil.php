<!Doctype html>
<html lang="fr">
<head><meta charset="UTF-8">
        <title>PAGE D'ACCUEIL</title>
        <link rel="stylesheet" href="thales.css" />
    </head>
    <body>
        <div class="banner">
            <nav id="titres">
                <h1 class="banner-title">PHOTO_ATB</h1>
            </nav>
        </div>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <form method="POST" action="pageaccueil.php">
			<p><label for="login"></label><input placeholder="prénom.nom" class="cadre" name="logine" type="text" required autofocus/></p>
			<p><label for="mdp"></label><input type="password" placeholder="mot de passe" class="cadre" name="mdp"  required /></p><br>
			<p><button class="cadre" name="envoi" type="submit" value="envoi">CONNEXION</button></p>
		</form>
        <?php 
        include("logs.php");
        error_reporting(E_ALL & ~E_WARNING);
        $mdp=htmlspecialchars($_POST['mdp']);
        $logine=htmlspecialchars($_POST['logine']);
        try { 
            $bd = new PDO("sqlite:dbsite.db"); } 
            catch (PDOException $e) { 
            die("Erreur: Connexion impossible"); }
    
            $sql = "SELECT MDP,TYPE,COMPTEUR FROM COMPTES WHERE LOGINE=:logine";
            $req = $bd->prepare ($sql);
            $req->bindParam(':logine', $logine);
            $req->execute();
            $lesEnreg= $req->fetch(PDO::FETCH_ASSOC);
            $req->closeCursor();
            session_start();
            if ($mdp!==""){
                if ($lesEnreg['COMPTEUR']<3){
                    if ($lesEnreg['MDP']==$mdp) {
                        $_SESSION['correct']="ok";
                        $sql = "SELECT * FROM COMPTES WHERE LOGINE=:logine";
                        $req = $bd->prepare ($sql);
                        $req->bindParam(':logine', $logine);
                        $req->execute();
                        $lesEnreg= $req->fetch(PDO::FETCH_ASSOC);
                        $req->closeCursor();
                        $_SESSION['ID_C']=$lesEnreg['ID_C'];
                        $_SESSION['TYPE']=$lesEnreg['TYPE'];
                        $_SESSION['LOGINE']=$lesEnreg['LOGINE'];
                        logs_login();
                        header("Location: photo.php");
                        exit;
                    }
                    else {
                        $_SESSION['correct']="pas_ok";
                        if ($lesEnreg['TYPE']!==1){
                            $sql = "SELECT COMPTEUR,TYPE FROM COMPTES WHERE LOGINE=:logine";
                            $req = $bd->prepare ($sql);
                            $req->bindParam(':logine', $logine);
                            $req->execute();
                            $lesEnreg= $req->fetch(PDO::FETCH_ASSOC);
                            $req->closeCursor();
                            if ($lesEnreg['COMPTEUR']==2 && $lesEnreg['TYPE']==3){
                                logs_user_bloque();
                            }
                            elseif ($lesEnreg['COMPTEUR']==2 && $lesEnreg['TYPE']==2){
                                logs_admin_bloque();
                            }
                            try { 
                                $bd = new PDO("sqlite:dbsite.db"); } 
                                catch (PDOException $e) { 
                                die("Erreur: Connexion impossible"); }
                                $sql = "UPDATE COMPTES SET COMPTEUR=COMPTEUR+1 WHERE LOGINE= :logine";
                                $req = $bd->prepare ($sql);
                                $req->bindParam(':logine', $logine);
                                $req->execute();
                                $lesEnreg = $req->fetchall();
                                echo "Mot de passe incorrect";
                                $req->closeCursor();
                                
                        }
                        else{
                            echo "login incorrect";
                        }
                    }
                }
                else{
                    echo "Compte bloqué";
                }
                
            }
            
        ?>
        <br><br><br><br>
        <a class="bouton">PRENDRE UNE PHOTO</a><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <p>AFIN DE CREER UN COMPTE, OU <br>REGLER UN PROBLEME DE MOT DE PASSE,<br>VEUILLEZ CONTACTER : </p>
        <a href="mailto:t.pouyez06@gmail.com">MAIL@ADMIN.COM</a>
    </body>
</html>