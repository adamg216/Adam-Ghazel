<?php
include("function.php");
include("logs.php");
session_start();
if ($_SESSION['correct'] !== 'ok') {
    header("Location: pageaccueil.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>PHOTO</title>
    <link rel="stylesheet" href="thales.css" />
</head>
<body>
    <div class="banner">
        <nav class="bandeau">
            <?php 
                if ($_SESSION['TYPE'] == 1){
                   echo "<a class='bouton' href='paneladmin.php'>SUPER ADMIN</a>";
                }
                if ($_SESSION['TYPE'] == 2){
                    echo "<a class='bouton' href='paneladmin.php'>ADMIN</a>";
                }
                if ($_SESSION['TYPE'] == 3){
                    echo "<a class='bouton'>USER</a>";
                }
            ?>
            <h1 class="banner-title">CONNECTÉ</h1>
            <a class="bouton" href="changepswd.php">Connecté(e) en tant que:<br><?php echo htmlspecialchars($_SESSION['LOGINE']); ?></a>
        </nav>
    </div>

    <div class="button-container">
        <form method="POST">
        <button class="bouton" name="take_picture" type="submit">PRENDRE UNE PHOTO</button>
       <?php if (isset($_POST['take_picture'])) {
    $cmd = 'python3 /home/thales11/codethales/take_picture.py 2>&1';
    $output = shell_exec($cmd);
    echo "<pre>$output</pre>";
}?> 
</form>
    </div>

    <form method="POST">
        <select name="selection" onchange="this.form.submit()">
            <option value="default">FILTRE PHOTOS</option>
            <option value="option1">TOUTES LES PHOTOS</option>
            <option value="option2">PAR TITRE</option>
            <option value="option3">PAR USER</option>
            <?php if ($_SESSION['TYPE']!=3){
                echo "<option value='option4'>PHOTO(S) SIGNALEES</option>";
            } ?>
        </select>
    </form>

    <?php
    if(!empty($_SESSION['selection']) && $_SESSION['selection'] == "default"){
        affiche_toutes_photos();
    }

    if (isset($_POST['selection'])) {
        $_SESSION['selection'] = $_POST['selection'];
    }

    // FILTRE: TOUTES LES PHOTOS
    if (!empty($_SESSION['selection']) && $_SESSION['selection'] == "option1") {
        affiche_toutes_photos();
    }

    // FILTRE: PAR TITRE
    if (!empty($_SESSION['selection']) && $_SESSION['selection'] == "option2") {
        ?>
        <form method="POST">
            <input type="text" name="titre_recherche" placeholder="Entrer un titre de photo" required>
            <button type="submit" name="recherche_titre">Rechercher</button>
        </form>
        <?php
        if (isset($_POST['recherche_titre'])) {
            echo "<table><tr><th>Titre</th><th>Image</th><th>Action</th><th>État</th></tr>";
            affiche_photos_par_titre(htmlspecialchars($_POST['titre_recherche']));
            echo "</table>";
        }
    }

    // FILTRE: PAR UTILISATEUR
    if (!empty($_SESSION['selection']) && $_SESSION['selection'] == "option3") {
        ?>
        <form method="POST">
            <input type="text" name="login_recherche" placeholder="Entrer un login utilisateur" required>
            <button type="submit" name="recherche_login">Rechercher</button>
        </form>
        <?php
        if (isset($_POST['recherche_login'])) {
            echo "<table><tr><th>Titre</th><th>Image</th><th>Action</th><th>État</th></tr>";
            affiche_photos_par_user(htmlspecialchars($_POST['login_recherche']));
            echo "</table>";
        }
    }

    // Filtre photos signalées
    if (!empty($_SESSION['selection']) && $_SESSION['selection'] == "option4") {
        print_reported_pic();
    }

    // SIGNALER une photo
    if (isset($_POST['signaler_photo'])) {
        report(intval($_POST['signaler_photo']));
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

    ?>


    <br><br><br><br><br>
    <form method="POST">
        <button type="submit" name="deco">Déconnexion</button>
    </form>

    <?php 
    if (isset($_POST['deco'])) {
        $_SESSION = array();
        session_destroy();
        header("Location: pageaccueil.php");
        exit;
    }
    ?>
</body>
</html>
