<?php
header('Content-Type: application/json');

$file = __DIR__ . '/tasks.json';
if (!file_exists($file)) {
    file_put_contents($file, '[]');
}

$tasks = json_decode(file_get_contents($file), true) ?: [];

function save($tasks, $file) {
    file_put_contents($file, json_encode($tasks, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

$action = $_GET['action'] ?? 'list';

switch ($action) {
    case 'list':
        echo json_encode($tasks);
        break;

    case 'add':
        $data = json_decode(file_get_contents('php://input'), true);
        if (!isset($data['text']) || trim($data['text']) === '') {
            http_response_code(400);
            echo json_encode(['error' => 'Texte manquant']);
            exit;
        }
        $id = count($tasks) ? max(array_column($tasks, 'id')) + 1 : 1;
        $tasks[] = ['id' => $id, 'text' => $data['text'], 'done' => false];
        save($tasks, $file);
        echo json_encode(['success' => true, 'id' => $id]);
        break;

    case 'toggle':
        $id = (int)($_GET['id'] ?? 0);
        foreach ($tasks as &$task) {
            if ($task['id'] === $id) {
                $task['done'] = !$task['done'];
                save($tasks, $file);
                echo json_encode(['success' => true]);
                exit;
            }
        }
        http_response_code(404);
        echo json_encode(['error' => 'Tâche non trouvée']);
        break;

    case 'delete':
        $id = (int)($_GET['id'] ?? 0);
        $before = count($tasks);
        $tasks = array_values(array_filter($tasks, fn($t) => $t['id'] !== $id));
        if (count($tasks) === $before) {
            http_response_code(404);
            echo json_encode(['error' => 'Tâche non trouvée']);
            exit;
        }
        save($tasks, $file);
        echo json_encode(['success' => true]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Action inconnue']);
}
?>