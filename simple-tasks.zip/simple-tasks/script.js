async function fetchTasks() {
  const res = await fetch('tasks.php?action=list');
  return await res.json();
}

function renderTasks(tasks) {
  const list = document.getElementById('task-list');
  list.innerHTML = '';
  tasks.forEach(task => {
    const li = document.createElement('li');
    li.dataset.id = task.id;
    li.className = task.done ? 'done' : '';
    li.innerHTML = \`
      <span class="text">\${task.text}</span>
      <div>
        <button class="toggle" title="Marquer comme \${task.done ? 'à faire' : 'faite'}">✓</button>
        <button class="delete" title="Supprimer">🗑️</button>
      </div>
    \`;
    list.appendChild(li);
  });
}

async function refresh() {
  try {
    const tasks = await fetchTasks();
    renderTasks(tasks);
  } catch (err) {
    showError(err.message);
  }
}

function showError(msg) {
  const errorEl = document.getElementById('error');
  errorEl.textContent = msg;
  errorEl.classList.remove('hidden');
  setTimeout(() => errorEl.classList.add('hidden'), 3000);
}

document.getElementById('task-form').addEventListener('submit', async e => {
  e.preventDefault();
  const input = document.getElementById('task-input');
  const text = input.value.trim();
  if (!text) return;
  input.value = '';

  try {
    await fetch('tasks.php?action=add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    refresh();
  } catch (err) {
    showError(err.message);
  }
});

document.getElementById('task-list').addEventListener('click', async e => {
  const li = e.target.closest('li');
  if (!li) return;
  const id = li.dataset.id;

  if (e.target.classList.contains('toggle')) {
    await fetch('tasks.php?action=toggle&id=' + id, { method: 'POST' });
    refresh();
  } else if (e.target.classList.contains('delete')) {
    await fetch('tasks.php?action=delete&id=' + id, { method: 'POST' });
    refresh();
  }
});

refresh();
