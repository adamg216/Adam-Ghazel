<?php
session_start();
$total = 0.0;
require 'products.php';

foreach ($_SESSION['cart'] ?? [] as $id => $qty) {
  $total += $products[$id]['price'] * $qty;
}

// On “vide” le panier pour simuler un achat
$_SESSION['cart'] = [];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Merci pour votre achat</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <h1>Merci 🎉</h1>
</header>
<main>
  <p>Votre commande fictive de <strong><?= number_format($total, 2, ',', ' '); ?> €</strong> a bien été prise en compte.</p>
  <p><a href="index.php">Retour à la boutique</a></p>
</main>
</body>
</html>