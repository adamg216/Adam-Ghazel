<?php
session_start();
require 'products.php';

// Retirer du panier ?
if (isset($_GET['del'])) {
  $id = (int)$_GET['del'];
  unset($_SESSION['cart'][$id]);
  header('Location: cart.php');
  exit;
}

$cart = $_SESSION['cart'] ?? [];
$total = 0.0;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Votre panier</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <h1>Votre panier</h1>
  <a href="index.php">← Continuer mes achats</a>
</header>
<main>
<?php if (!$cart): ?>
  <p>Votre panier est vide.</p>
<?php else: ?>
<table>
  <tr><th>Produit</th><th>Qté</th><th>Prix</th><th></th></tr>
  <?php foreach ($cart as $id => $qty):
        $p = $products[$id];
        $line = $p['price'] * $qty;
        $total += $line; ?>
  <tr>
    <td><?= htmlspecialchars($p['name']); ?></td>
    <td><?= $qty; ?></td>
    <td><?= number_format($line, 2, ',', ' '); ?> €</td>
    <td><a href="?del=<?= $id; ?>">Supprimer</a></td>
  </tr>
  <?php endforeach; ?>
</table>
<p class="total">Total : <?= number_format($total, 2, ',', ' '); ?> €</p>
<a href="checkout.php"><button>Paiement</button></a>
<?php endif; ?>
</main>
</body>
</html>