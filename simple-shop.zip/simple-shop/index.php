<?php
session_start();
require 'products.php';

// Ajoute au panier ?
if (isset($_GET['add'])) {
  $id = (int)$_GET['add'];
  $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + 1;
  header('Location: index.php'); // évite un double add via F5
  exit;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Boutique simple</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <h1>Boutique simple</h1>
  <a href="cart.php">Panier (<?= array_sum($_SESSION['cart'] ?? []); ?>)</a>
</header>

<main>
  <div class="product-grid">
    <?php foreach ($products as $id => $p): ?>
    <div class="card">
      <?php if(isset($p['img'])): ?>
        <img src="<?= $p['img']; ?>" alt="">
      <?php endif; ?>
      <h3><?= htmlspecialchars($p['name']); ?></h3>
      <p class="price"><?= number_format($p['price'], 2, ',', ' '); ?> €</p>
      <a href="?add=<?= $id; ?>"><button>Ajouter</button></a>
    </div>
    <?php endforeach; ?>
  </div>
</main>
</body>
</html>