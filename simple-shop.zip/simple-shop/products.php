<?php
// Tableau statique : id, nom, prix (euros), image optionnelle
$products = [
  1 => ['name' => 'T-shirt Chat',  'price' => 19.90, 'img' => 'images/cat-shirt.jpg'],
  2 => ['name' => 'Mug Caféine',   'price' => 12.50, 'img' => 'images/coffee-mug.jpg'],
  3 => ['name' => 'Sticker Pixel', 'price' =>  2.00, 'img' => 'images/pixel-sticker.jpg'],
];
?>